<?php 
$username=$_POST['username'];
//1  接收前端传过来的参数
$ori_file_name=$_POST['filename'];  //原始文件的文件名
$file=$_FILES['file'];
$tmp_name=$file['tmp_name'];   //临时文件名
$blob_num=$_POST['blob_num'];
$total_blob_num=$_POST['total_blob_num']; //切片总数量

//2 将上传的文件移动的指定的位置
$uploadDir='upload';     //目标文件夹
$slice_file_name=$uploadDir.'/'.$ori_file_name.'_'.$blob_num;     //切片文件的文件名
move_uploaded_file($tmp_name, $slice_file_name);            //将临时文件移动到目标位置并重命名

//3  合并所有切片
if ($blob_num==$total_blob_num) {
	$blob='';
	for ($i=1; $i<=$total_blob_num; $i++) { 
		//获取并连接各文件数据
		$blob.=file_get_contents($uploadDir.'/'.$ori_file_name.'_'.$i);
	}
	file_put_contents($uploadDir.'/'.$ori_file_name,$blob);
//	删除所有切片
	 for ($i=1; $i <=$total_blob_num ; $i++) {
	 	unlink($uploadDir.'/'.$ori_file_name.'_'.$i);
	 }
}
	//5   构造返回前台的数组
	$data=array(
          'username'=>$username,
		'filename'=>$uploadDir.'/'.$ori_file_name,
		'tmp_name'=>$tmp_name,
		'blob_num'=>$blob_num,
		'slice_file_name'=>$slice_file_name,
		);

	//  6 向前台返回json格式数据
	echo json_encode($data);
	






 ?>